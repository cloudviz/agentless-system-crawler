
import socket

from pyroute2.netlink.nfnetlink import NFNL_SUBSYS_CTNETLINK

from pyroute2ext.conntrack import ct_msg
from pyroute2ext.conntrack import IPCTNL_MSG_CT_NEW
from pyroute2ext.conntrack import IPCTNL_MSG_CT_DELETE

IPFIX_octetDeltaCount = 1
IPFIX_packetDeltaCount = 2
IPFIX_protocolIdentifier = 4
IPFIX_sourceTransportPort = 7
IPFIX_sourceIPv4Address = 8
IPFIX_destinationTransportPort = 11
IPFIX_destinationIPv4Address = 12
IPFIX_icmpTypeCodeIPv4 = 32
IPFIX_icmpTypeCodeIPv6 = 139
IPFIX_flowId = 148
IPFIX_postNATSourceIPv4Address = 225
IPFIX_postNATDestinationIPv4Address = 226
IPFIX_postNAPTSourceTransportPort = 227
IPFIX_postNAPTDestinationTransportPort = 228
IPFIX_natEvent = 230
IPFIX_initiatorOctets = 231
IPFIX_responderOctets = 232
IPFIX_natType = 297
IPFIX_initiatorPackets = 298
IPFIX_responderPackets = 299


class NetlinkConntrackMsg(object):
    """ A class working on conntrack netlink messages """
    def __init__(self, netlinkdata):
        self.msg = ct_msg(netlinkdata)
        self.msg.decode()

    def todict(self):
        """
          Convert the netlink conntrack message data to a dictionary
          where the keys are values from IPFIX
        """

        type = self.msg['header']['type']
        if (type >> 8) == NFNL_SUBSYS_CTNETLINK:
            type &= 0xff

            if type not in [IPCTNL_MSG_CT_NEW, IPCTNL_MSG_CT_DELETE]:
                # wrong message type
                return {}
        else:
            # from wrong subsystem
            return {}

        tuple_orig = self.msg.get_attr('CTA_TUPLE_ORIG')
        if not tuple_orig:
            return {}
        tuple_orig_ip = tuple_orig.get_attr('CTA_TUPLE_IP')
        if not tuple_orig_ip:
            return {}
        tuple_orig_proto = tuple_orig.get_attr('CTA_TUPLE_PROTO')
        if not tuple_orig_proto:
            return {}

        tuple_reply = self.msg.get_attr('CTA_TUPLE_REPLY')
        if not tuple_reply:
            return {}
        tuple_reply_ip = tuple_reply.get_attr('CTA_TUPLE_IP')
        if not tuple_reply_ip:
            return {}
        tuple_reply_proto = tuple_reply.get_attr('CTA_TUPLE_PROTO')
        if not tuple_reply_proto:
            return {}

        proto = tuple_orig_proto.get_attr('CTA_PROTO_NUM')
        res = {
            IPFIX_sourceIPv4Address: tuple_orig_ip.get_attr('CTA_IP_V4_SRC'),
            IPFIX_destinationIPv4Address:
                tuple_orig_ip.get_attr('CTA_IP_V4_DST'),
            IPFIX_protocolIdentifier: proto,
            IPFIX_flowId: self.msg.get_attr('CTA_ID'),
        }

        if proto in [socket.IPPROTO_TCP, socket.IPPROTO_UDP]:
            res[IPFIX_sourceTransportPort] = \
                tuple_orig_proto.get_attr('CTA_PROTO_SRC_PORT')
            res[IPFIX_destinationTransportPort] = \
                tuple_orig_proto.get_attr('CTA_PROTO_DST_PORT')
        elif proto in [socket.IPPROTO_ICMP]:
            res[IPFIX_icmpTypeCodeIPv4] = \
                tuple_orig_proto.get_attr('CTA_PROTO_ICMP_TYPE') << 8 | \
                tuple_orig_proto.get_attr('CTA_PROTO_ICMP_CODE')
        elif proto in [socket.IPPROTO_ICMPV6]:
            res[IPFIX_icmpTypeCodeIPv6] = \
                tuple_orig_proto.get_attr('CTA_PROTO_ICMPV6_TYPE') << 8 | \
                tuple_orig_proto.get_attr('CTA_PROTO_ICMPV6_CODE')

        # NATing ?
        nat = False
        addr = tuple_reply_ip.get_attr('CTA_IP_V4_SRC')
        if res[IPFIX_destinationIPv4Address] != addr:
            res[IPFIX_postNATDestinationIPv4Address] = addr
            nat = True

        addr = tuple_reply_ip.get_attr('CTA_IP_V4_DST')
        if res[IPFIX_sourceIPv4Address] != addr:
            res[IPFIX_postNATSourceIPv4Address] = addr
            nat = True

        # port NATing ?
        # TCP/UDP connection attempt could result in ICMP reject
        if proto in [socket.IPPROTO_TCP, socket.IPPROTO_UDP]:
            r_proto = tuple_reply_proto.get_attr('CTA_PROTO_NUM')
            if proto == r_proto:
                p = tuple_orig_proto.get_attr('CTA_PROTO_SRC_PORT')
                if res[IPFIX_destinationTransportPort] != p:
                    res[IPFIX_postNAPTDestinationTransportPort] = p
                    nat = True

                p = tuple_orig_proto.get_attr('CTA_PROTO_DST_PORT')
                if res[IPFIX_sourceTransportPort] != p:
                    res[IPFIX_postNAPTSourceTransportPort] = p
                    nat = True

        if nat:
            res[IPFIX_natType] = 1
            if type == IPCTNL_MSG_CT_NEW:
                res[IPFIX_natEvent] = 4
            else:
                res[IPFIX_natEvent] = 5
        else:
            res[IPFIX_natType] = 4

        counters_orig = self.msg.get_attr('CTA_COUNTERS_ORIG')
        counters_reply = self.msg.get_attr('CTA_COUNTERS_REPLY')
        if counters_orig and counters_reply:
            snd_pkts = counters_orig.get_attr('CTA_COUNTERS_PACKETS')
            snd_bytes = counters_orig.get_attr('CTA_COUNTERS_BYTES')
            rcv_pkts = counters_reply.get_attr('CTA_COUNTERS_PACKETS')
            rcv_bytes = counters_reply.get_attr('CTA_COUNTERS_BYTES')
            res[IPFIX_octetDeltaCount] = snd_bytes + rcv_bytes
            res[IPFIX_packetDeltaCount] = snd_pkts + rcv_pkts
            res[IPFIX_initiatorOctets] = snd_bytes
            res[IPFIX_responderOctets] = rcv_bytes
            res[IPFIX_initiatorPackets] = snd_pkts
            res[IPFIX_responderPackets] = rcv_pkts

        return res
