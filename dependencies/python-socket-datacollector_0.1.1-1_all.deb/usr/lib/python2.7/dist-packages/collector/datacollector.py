import base64
import json
import os
import socket
import time


class DataCollector(object):
    """ Collect data received on a socket and write into file """

    def __init__(self, socket, targetdir, filepattern, user_metadata):
        self.socket = socket
        self.targetdir = targetdir
        self.filepattern = filepattern
        if user_metadata:
            self.user_metadata = user_metadata
        else:
            self.user_metadata = {}

        self.recvdata = []

        self.md_filter = None

    def set_md_filter(self, md_filter):
        """
          Set a filter for the metadata to write into the file.
          Only those listed in the md_filter will be written.
          The md_filter may either be None or a list.
        """
        self.md_filter = md_filter

    def handle_socket(self):
        """
          handle data received on a socket
        """
        data, addr = self.socket.recvfrom(65536)
        self.recvdata.append((data, addr, time.time()))

    def format_data(self, data, addr, timestamp):
        """
          format the data for writing out into a file
        """
        output = {
            'metadata': self.user_metadata.copy(),
            'data': base64.b64encode(data),
        }
        output['metadata'].update({
            'sender': addr[0],
            'sport': addr[1],
            'timestamp': timestamp,
        })
        if self.md_filter:
            for key in output['metadata'].keys():
                if not key in self.md_filter:
                    del output['metadata'][key]

        return output

    def create_filename(self):
        """
          create the filename to write the data into
        """
        params = {
            'pid': '%d' % os.getpid(),
            'timestamp': str(int(time.time())),
        }
        params.update(self.user_metadata)
        return self.targetdir + '/' + self.filepattern.format(**params)

    def write_data(self):
        """
          write all received data into a file
        """

        if not len(self.recvdata):
            return

        results = []

        for recvdata in self.recvdata:
            data, addr, timestamp = recvdata

            result = self.format_data(data, addr, timestamp)

            results.append(result)

        self.recvdata = []

        filename = self.create_filename()
        tmpfile = filename + ".tmp"
        try:
            with open(tmpfile, 'w') as outfile:
                json.dump(results, outfile)
            os.rename(tmpfile, filename)
        except Exception:
            pass
